package testfw;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import generic.BaseTest;
import generic.FWUtil;

public class TestA extends BaseTest{
	
	@Test
	public void testA1() {
		}
	
	}






